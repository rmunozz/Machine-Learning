function [K] = linear_kernel(X1, X2)
	
	K = X1 * transpose(X2);
	
end